Write-Host 'Running harness tests...'
# TODO: wire harness tests here
Write-Host 'OK (no harness yet)'
