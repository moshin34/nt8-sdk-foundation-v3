## What changed?
-

## Why?
-

## How tested?
- [ ] Guard passed (`powershell .\tools\guard.ps1`)
- [ ] Build ok (`powershell .\tools\build.ps1`)
- [ ] Harness ok (`powershell .\tools\test.ps1`)
- [ ] NT8 compile ok (if NT8Bridge/Strategies touched)

## Risk / Rollback
-

## Screenshots / Logs
